import {defineComponent,ref,watch} from 'vue';
export function dateDigits(value:string,limit:number){return value.replace(/[０-９]/g,c=>String.fromCharCode(c.charCodeAt(0)-0xfee0)).replace(/\D/g,'').slice(0,limit);}
export function joinBirthDate(parts:string[]){return parts.every(Boolean)?`${parts[0]}-${parts[1].padStart(2,'0')}-${parts[2].padStart(2,'0')}`:'';}
export const BirthDateInput=defineComponent({
 props:{modelValue:{type:String,default:''},calendar:{type:String,default:'solar'}},emits:['update:modelValue'],
 setup(props,{emit}){
  const parts=ref(['','','']);let lastEmitted:string|undefined;
  watch(()=>props.modelValue,value=>{if(value===lastEmitted)return;parts.value=value?value.split('-'):['','',''];},{immediate:true});
  function input(i:number,event:Event){const el=event.target as HTMLInputElement;const value=dateDigits(el.value,i===0?4:2);el.value=value;parts.value[i]=value;lastEmitted=joinBirthDate(parts.value);emit('update:modelValue',lastEmitted);}
  function pad(i:number){if(parts.value[i])parts.value[i]=parts.value[i].padStart(i===0?4:2,'0');}
  return{parts,input,pad};
 },template:`<fieldset class="birth-date-fields"><legend>出生日期 · {{calendar==='lunar'?'农历':'公历'}}</legend><div class="birth-date-row"><label>年<input :value="parts[0]" @input="input(0,$event)" aria-label="出生年份" inputmode="numeric" autocomplete="off" maxlength="4" pattern="[0-9]{4}" placeholder="1990" required></label><label>月<input :value="parts[1]" @input="input(1,$event)" @blur="pad(1)" aria-label="出生月份" inputmode="numeric" autocomplete="off" maxlength="2" pattern="(0?[1-9]|1[0-2])" placeholder="06" required></label><label>日<input :value="parts[2]" @input="input(2,$event)" @blur="pad(2)" aria-label="出生日" inputmode="numeric" autocomplete="off" maxlength="2" pattern="(0?[1-9]|[12][0-9]|3[01])" placeholder="15" required></label></div><p class="hint">支持 1901–2100 年，只填数字，无需输入横线。{{calendar==='lunar'?'请填写农历数字月份；闰月另行勾选。':''}}</p></fieldset>`
});
