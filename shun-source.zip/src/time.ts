import { Temporal } from '@js-temporal/polyfill';
import { Solar, Lunar } from 'lunar-javascript';
import * as A from 'astronomy-engine';
import type { BirthProfile } from './types';
export const norm = (x: number) => ((x % 360) + 360) % 360;
export function validateProfile(p: BirthProfile) {
  if (!p.nickname.trim() || p.nickname.length > 40) throw new Error('昵称需要 1–40 个字符');
  if (!['male','female','unspecified'].includes(p.gender) || !['solar','lunar'].includes(p.calendar) || !['23','00'].includes(p.zi_hour_rule)) throw new Error('档案选项无效');
  if (!Number.isFinite(p.latitude) || Math.abs(p.latitude)>90 || !Number.isFinite(p.longitude) || Math.abs(p.longitude)>180) throw new Error('经纬度超出范围');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(p.birth_date)) throw new Error('日期格式应为 YYYY-MM-DD');
  const [y,m,d] = p.birth_date.split('-').map(Number);
  if(y<1901||y>2100) throw new Error('首版支持 1901–2100 年；历史年份仍需人工复核');
  if(p.calendar==='solar'){try{Temporal.PlainDate.from(p.birth_date, {overflow:'reject'});}catch{throw new Error('公历日期不存在，请检查月份、天数及闰年（例如平年没有 2 月 29 日）');}}
  else {
    try {
    const l = Lunar.fromYmd(y, p.is_leap_month ? -m:m,d);
    if(l.getYear()!==y || Math.abs(l.getMonth())!==m || l.getDay()!==d) throw new Error('农历日期无效');
    }catch{throw new Error('农历日期不存在，请检查大小月天数及该年是否有对应闰月');}
  }
  if(p.birth_time!==null && !/^([01]\d|2[0-3]):[0-5]\d$/.test(p.birth_time)) throw new Error('时间格式应为 HH:mm');
  try{new Intl.DateTimeFormat('en', { timeZone: p.timezone }).format();}catch{throw new Error('时区无效，请重新选择出生地，或填写 Asia/Shanghai 等 IANA 时区');}
}
export function solarDate(p: BirthProfile): string {
  if(p.calendar==='solar') return p.birth_date;
  const [y,m,d] = p.birth_date.split('-').map(Number);
  return Lunar.fromYmd(y,p.is_leap_month?-m:m,d).getSolar().toYmd();
}
export function resolveTime(p: BirthProfile) {
  validateProfile(p);
  const civil = Temporal.PlainDateTime.from(`${solarDate(p)}T${p.birth_time || '12:00'}`);
  // Reject ambiguous/nonexistent historical DST wall-clock times instead of guessing.
  const zoned = civil.toZonedDateTime(p.timezone, { disambiguation:'reject' });
  const instant = new Date(zoned.epochMilliseconds);
  let calc = civil;
  if(p.true_solar_time && p.birth_time) {
    const sun = A.EquatorFromVector(A.RotateVector(A.Rotation_EQJ_EQD(instant), A.GeoVector(A.Body.Sun,instant,true)));
    const apparentHour = norm(A.SiderealTime(instant)*15 + p.longitude - sun.ra*15 +180)/15;
    const mean = Temporal.Instant.fromEpochMilliseconds(zoned.epochMilliseconds + Math.round(p.longitude*240000)).toZonedDateTimeISO('UTC').toPlainDateTime();
    const meanHour = mean.hour+mean.minute/60+mean.second/3600;
    const delta = ((apparentHour-meanHour+36)%24)-12;
    calc = mean.add({seconds:Math.round(delta*3600)});
  }
  const beijing = zoned.withTimeZone('+08:00').toPlainDateTime();
  return { instant, calc, civil, beijing, known: p.birth_time!==null };
}
export function lunarFor(t: Temporal.PlainDateTime) { return Solar.fromYmdHms(t.year,t.month,t.day,t.hour,t.minute,t.second).getLunar(); }
