import type { ExportBundle } from './types';
import { validateProfile } from './time';

export const MAX_BACKUP_BYTES = 10 * 1024 * 1024;
type Check = (value: unknown, path: string) => any;
const invalid = (path: string): never => { throw new Error(`备份字段无效：${path}`); };
const string = (max = 12000): Check => (v,p) => typeof v==='string' && v.length<=max ? v : invalid(p);
const number = (min=-Infinity,max=Infinity,integer=false): Check => (v,p) => typeof v==='number' && Number.isFinite(v) && v>=min && v<=max && (!integer||Number.isInteger(v)) ? v : invalid(p);
const bool: Check = (v,p) => typeof v==='boolean'?v:invalid(p);
const choice = (...values: unknown[]): Check => (v,p) => values.includes(v)?v:invalid(p);
const nullable = (check: Check):Check => (v,p) => v===null?null:check(v,p);
const optional = (check: Check):Check => (v,p) => v===undefined?undefined:check(v,p);
const list = (check: Check,max=10000):Check => (v,p) => Array.isArray(v)&&v.length<=max?v.map((x,i)=>check(x,`${p}[${i}]`)):invalid(p);
const object = (shape: Record<string,Check>):Check => (v,p) => {
  if(!v||typeof v!=='object'||Array.isArray(v)) return invalid(p);
  const out:Record<string,unknown>={};
  for(const [key,check] of Object.entries(shape)) { const value=check((v as Record<string,unknown>)[key],`${p}.${key}`); if(value!==undefined)out[key]=value; }
  return out;
};
const id:Check=(v,p)=>typeof v==='string'&&v.length>0&&v.length<=100?v:invalid(p);
const timestamp:Check=(v,p)=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT/.test(v)&&Number.isFinite(Date.parse(v))?v:invalid(p);
const base={id,created_at:timestamp,updated_at:timestamp};
const profileShape={...base,nickname:string(40),gender:choice('male','female','unspecified'),calendar:choice('solar','lunar'),birth_date:string(10),birth_time:nullable(string(5)),is_leap_month:bool,birthplace:string(100),latitude:number(-90,90),longitude:number(-180,180),timezone:string(100),true_solar_time:bool,zi_hour_rule:choice('23','00'),revision:number(1,1e9,true)};
const profile=object(profileShape);
const {nickname:_,...snapshotShape}=profileShape;
const elements:Check=(v,p)=>{
  if(!v||typeof v!=='object'||Array.isArray(v))return invalid(p);
  const out:Record<string,number>={};
  for(const [k,x] of Object.entries(v)){if(!['木','火','土','金','水','风'].includes(k))return invalid(p);out[k]=number(0,10,true)(x,p+'.'+k);}
  return out;
};
const result=object({summary:string(500),day_master:optional(string(2)),
  pillars:optional(list(object({label:string(10),ganzhi:string(2),hidden:list(string(2),4),deity:string(20),elements:string(2)}),4)),
  elements:optional(elements),luck:optional(list(object({ganzhi:string(2),start:number(1800,2300,true),end:number(1800,2300,true)}),20)),
  planets:optional(list(object({name:string(20),longitude:number(0,359.999999999),sign:string(20),house:nullable(number(1,12,true))}),10)),
  ascendant:optional(number(0,359.999999999)),houses:optional(list(number(0,359.999999999),12)),
  aspects:optional(list(object({a:string(20),b:string(20),name:choice('合相','六合','刑相','拱相','冲相'),angle:number(0,180),orb:number(0,6)}),100)),
  palaces:optional(list(object({name:string(20),branch:string(10),stars:list(string(60),30),minor:list(string(60),60),decade:list(number(0,200,true),2),body:bool}),12)),
  mansion:optional(string(50)),relation_status:optional(string(1000))});
const chart=object({...base,profile_id:id,profile_revision:number(1,1e9,true),type:choice('bazi','western','ziwei','xingsu'),input:object(snapshotShape),utc:nullable(timestamp),calculation_time:string(100),engine:string(100),rules:list(string(2000),50),warnings:list(string(2000),50),verification:choice('needs_manual_review'),result,imported_at:optional(timestamp)});
const synastry=object({...base,profile_ids:list(id,2),profile_revisions:list(number(1,1e9,true),2),chart_ids:list(id,20),type:choice('combined'),rule_version:string(100),dimensions:list(object({key:string(100),label:string(100),score:nullable(number(0,100)),max:choice(100),explanation:string(2000),evidence:list(string(2000),500)}),20),disclaimer:string(1000),imported_at:optional(timestamp)});
const favorite=object({...base,target_type:choice('article','chart'),target_id:id});
const settings=object({...base,id:choice('singleton'),theme:choice('system','light','dark'),default_timezone:string(100),true_solar_default:bool,zi_hour_rule:choice('23','00'),ai_enabled:bool,ai_proxy:string(1000)});
const bundle=object({format:choice('shun-personal'),schema_version:choice(1),exported_at:timestamp,profiles:list(profile,1000),charts:list(chart),synastries:list(synastry),favorites:list(favorite),settings:list(settings,1)});

/** Only recognized fields survive parsing. Imported snapshots remain explicitly unverified. */
export function parseBackup(text:string):ExportBundle {
  if(new TextEncoder().encode(text).byteLength>MAX_BACKUP_BYTES)throw new Error('备份不能超过 10 MB');
  let raw:unknown;
  try {raw=JSON.parse(text,(key,value)=>{if(['__proto__','prototype','constructor'].includes(key))throw new Error('不允许的字段');return value;});}catch {throw new Error('文件不是有效的安全 JSON 备份');}
  const data=bundle(raw,'backup') as ExportBundle;
  for(const rows of [data.profiles,data.charts,data.synastries,data.favorites])if(new Set(rows.map(x=>x.id)).size!==rows.length)throw new Error('备份包含重复记录 ID');
  const profiles=new Map(data.profiles.map(p=>[p.id,p]));const charts=new Map(data.charts.map(c=>[c.id,c]));
  data.profiles.forEach(validateProfile);
  for(const c of data.charts){
    if(!profiles.has(c.profile_id)||c.input.id!==c.profile_id||c.profile_revision!==c.input.revision)throw new Error('排盘与出生档案引用不一致');
    validateProfile({...c.input,nickname:'备份快照'});
    if(c.type==='bazi'||c.type==='western'){
      const expected=c.type==='bazi'?['木','火','土','金','水']:['火','土','风','水'];
      const counts=c.result.elements;
      if(!counts||Object.keys(counts).length!==expected.length||expected.some(k=>counts[k]===undefined)||Object.values(counts).reduce((a,b)=>a+b,0)!==(c.type==='bazi'?8:10))throw new Error('元素计数结构或总数无效');
    }
    if(c.type==='bazi'&&(c.result.pillars?.length!==4||!c.result.elements))throw new Error('八字快照结构不完整');
    if(c.type==='western'){
      const names=c.result.planets?.map(p=>p.name)||[];
      if(names.length!==10||new Set(names).size!==10||!c.result.aspects||!c.result.houses)throw new Error('星盘快照结构不完整');
      if(c.result.aspects.some(a=>!names.includes(a.a)||!names.includes(a.b)))throw new Error('相位引用了不存在的行星');
      if(c.result.ascendant!==undefined&&c.result.houses.length!==12)throw new Error('宫位快照结构不完整');
    }
    if(c.type==='ziwei'&&c.result.palaces?.length!==12)throw new Error('紫微快照结构不完整');
    if(c.type==='xingsu'&&!c.result.mansion)throw new Error('星宿快照结构不完整');
  }
  for(const s of data.synastries)if(s.profile_ids.length!==2||s.profile_ids[0]===s.profile_ids[1]||s.profile_revisions.length!==2||s.profile_ids.some(id=>!profiles.has(id))||s.chart_ids.some(id=>!charts.has(id)||!s.profile_ids.includes(charts.get(id)!.profile_id)))throw new Error('合盘关联档案或快照缺失');
  for(const f of data.favorites)if(f.target_type==='chart'&&!charts.has(f.target_id))throw new Error('收藏引用了不存在的排盘');
  return data;
}
