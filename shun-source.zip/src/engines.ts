import * as A from 'astronomy-engine';
import { LunarUtil } from 'lunar-javascript';
import { astro } from 'iztro';
import { resolveTime, lunarFor, norm } from './time';
import { entity, DISCLAIMER, type BirthProfile, type ChartRecord, type ChartType, type Aspect, type Planet, type SynastryRecord } from './types';
export const labels: Record<ChartType,string> = {bazi:'八字',western:'西方星盘',ziwei:'紫微斗数',xingsu:'星宿'};
export const signs = ['白羊','金牛','双子','巨蟹','狮子','处女','天秤','天蝎','射手','摩羯','水瓶','双鱼'];
export const angularDistance = (a:number,b:number) => Math.abs(((a-b+540)%360)-180);
export function aspects(left: Planet[], right?: Planet[]): Aspect[] {
  const out: Aspect[] = [];
  const rules: [string,number,number][] = [['合相',0,6],['六合',60,4],['刑相',90,6],['拱相',120,6],['冲相',180,6]];
  left.forEach((a,i)=>(right || left).forEach((b,j)=>{
    if(!right && j<=i) return;
    const delta=angularDistance(a.longitude,b.longitude);
    const rule=rules.find(([,angle,orb])=>Math.abs(delta-angle)<=orb);
    if(rule) out.push({a:a.name,b:b.name,name:rule[0],angle:rule[1],orb:+Math.abs(delta-rule[1]).toFixed(3)});
  })); return out;
}
export function ascendant(date:Date, latitude:number, longitude:number) {
  const r=Math.PI/180, theta=(A.SiderealTime(date)*15+longitude)*r, eps=A.e_tilt(A.MakeTime(date)).tobl*r;
  return norm(Math.atan2(Math.cos(theta),-(Math.sin(theta)*Math.cos(eps)+Math.tan(latitude*r)*Math.sin(eps)))/r);
}
export function calculate(p:BirthProfile,type:ChartType):ChartRecord {
  const t=resolveTime(p), {nickname:_,...input}=p;
  const c:ChartRecord={...entity(),profile_id:p.id,profile_revision:p.revision,type,input,utc:t.known?t.instant.toISOString():null,
    calculation_time:t.calc.toString(),engine:'',rules:[],warnings:['尚未完成独立专业工具逐项精度验收，请人工复核边界出生时间。'],verification:'needs_manual_review',result:{summary:''}};
  if(type!=='xingsu' && !t.known) throw new Error('该模块需要已知出生时间；不会用中午代填生成结果。请补充档案。');
  if(p.true_solar_time) c.warnings.push(type==='western'?'西方星盘使用真实 UTC 时刻，不使用真太阳时改写出生瞬间。':'真太阳时由太阳视赤经与地方恒星时计算；节气年、月仍以同一 UTC 瞬间判断。');
  if(type==='bazi') {
    const ec=lunarFor(t.calc).getEightChar(), boundary=lunarFor(t.beijing).getEightChar();
    ec.setSect(p.zi_hour_rule==='23'?1:2);
    const day=ec.getDayGan();
    const pillars=[['年',boundary.getYear()],['月',boundary.getMonth()],['日',ec.getDay()],['时',ec.getTime()]].map(([label,ganzhi])=>({
      label,ganzhi,hidden:LunarUtil.ZHI_HIDE_GAN[ganzhi[1]],deity:label==='日'?'日主':LunarUtil.SHI_SHEN[day+ganzhi[0]],elements:LunarUtil.WU_XING_GAN[ganzhi[0]]+LunarUtil.WU_XING_ZHI[ganzhi[1]]
    }));
    const elements:Record<string,number>={木:0,火:0,土:0,金:0,水:0};
    pillars.forEach(x=>[...x.elements].forEach(e=>elements[e]++));
    c.engine='lunar-javascript@1.7.7'; c.rules=['立春换年，节气换月（UTC+08:00 节气基准）',`日时按${p.true_solar_time?'真太阳时':'出生地民用时'}；${p.zi_hour_rule}时换日`,'五行统计仅计四柱表层八字，各 1 权重，不等于旺衰或喜用神'];
    c.result={summary:`${day}日主 · ${pillars.map(x=>x.ganzhi).join(' ')}`,pillars,elements,day_master:day};
    if(p.gender!=='unspecified' && p.timezone==='Asia/Shanghai' && !p.true_solar_time && t.civil.equals(t.beijing)) {
      c.result.luck=ec.getYun(p.gender==='male'?1:0,2).getDaYun(9).slice(1).map((x:any)=>({ganzhi:x.getGanZhi(),start:x.getStartYear(),end:x.getEndYear()}));
      c.rules.push('大运：lunar 起运 sect=2，按传统性别顺逆排法，年份区间仅作概览');
    } else c.warnings.push('当前性别/时区/真太阳时组合尚未验收起运年龄，暂不输出大运。');
  } else if(type==='western') {
    const planets:Planet[]=[['太阳',A.Body.Sun],['月亮',A.Body.Moon],['水星',A.Body.Mercury],['金星',A.Body.Venus],['火星',A.Body.Mars],['木星',A.Body.Jupiter],['土星',A.Body.Saturn],['天王星',A.Body.Uranus],['海王星',A.Body.Neptune],['冥王星',A.Body.Pluto]].map(([name,body])=>{
      const longitude=norm(A.Ecliptic(A.GeoVector(body as A.Body,t.instant,true)).elon);
      return {name,longitude,sign:signs[Math.floor(longitude/30)],house:null};
    });
    let asc:number|undefined;
    if(Math.abs(p.latitude)<66) { asc=ascendant(t.instant,p.latitude,p.longitude); planets.forEach(x=>x.house=Math.floor(norm(x.longitude-asc!)/30)+1); }
    else c.warnings.push('高纬度上升与宫位尚未验收，暂不输出；行星地心黄经仍可查看。');
    const elements:Record<string,number>={火:0,土:0,风:0,水:0};
    planets.forEach(x=>elements[['火','土','风','水'][Math.floor(x.longitude/30)%4]]++);
    c.engine='astronomy-engine@2.1.19';c.rules=['地心、热带黄道、日期真黄道坐标；包含光行时与光行差','等宫制：上升起每 30° 一宫；非普拉西德制','相位：合/刑/拱/冲 6°，六合 4°；行星等权元素统计'];
    c.result={summary:`太阳${planets[0].sign} · 月亮${planets[1].sign}${asc!==undefined?' · 上升'+signs[Math.floor(asc/30)]:''}`,planets,ascendant:asc,houses:asc===undefined?[]:Array.from({length:12},(_,i)=>norm(asc!+i*30)),aspects:aspects(planets),elements};
  } else if(type==='ziwei') {
    if(p.gender==='unspecified') throw new Error('当前紫微库需要传统排盘性别，请在档案中选择后再计算。');
    astro.config({yearDivide:'normal',horoscopeDivide:'normal',ageDivide:'normal',dayDivide:p.zi_hour_rule==='23'?'forward':'current',algorithm:'default'});
    const chart=astro.bySolar(t.calc.toPlainDate().toString(),Math.floor((t.calc.hour+1)/2),p.gender==='male'?'男':'女',true,'zh-CN');
    const star=(s:any)=>s.name+(s.brightness?`·${s.brightness}`:'')+(s.mutagen?`·化${s.mutagen}`:'');
    c.engine='iztro@2.5.7';c.rules=['通行安星法；正月初一分年','闰月修正：十五日及以前算本月，之后算下月',`晚子时${p.zi_hour_rule==='23'?'算次日':'算当日'}；四化使用库默认表`];
    c.result={summary:`${chart.fiveElementsClass} · 命主${chart.soul} · 身主${chart.body}`,palaces:chart.palaces.map(x=>({name:x.name,branch:x.heavenlyStem+x.earthlyBranch,stars:x.majorStars.map(star),minor:[...x.minorStars,...x.adjectiveStars].map(star),decade:x.decadal.range,body:x.isBodyPalace}))};
  } else {
    const l=lunarFor(t.civil);
    c.engine='lunar-javascript@1.7.7';c.rules=['输出 Lunar.getXiu 的历法二十八宿值，按档案民用日期','此值不是月球实际所在星宿，也不是二十七宿本命宿'];
    c.result={summary:`历法二十八宿 · ${l.getXiu()}宿`,mansion:l.getXiu()+l.getZheng()+l.getAnimal(),relation_status:'二十七宿本命宿、值日宿及双方关系算法来源待验证，暂不输出。'};
  }
  return c;
}
export function compare(a:BirthProfile,b:BirthProfile,charts:ChartRecord[]):SynastryRecord {
  if(a.id===b.id) throw new Error('请选择两个不同的出生档案');
  const get=(id:string,type:ChartType)=>charts.find(x=>x.profile_id===id&&x.type===type)?.result;
  const ba=get(a.id,'bazi'),bb=get(b.id,'bazi'),wa=get(a.id,'western'),wb=get(b.id,'western');
  const distance=ba?.elements&&bb?.elements?Object.keys(ba.elements).reduce((s,k)=>s+Math.abs(ba.elements![k]-bb.elements![k]),0)/16:null;
  const cross=wa?.planets&&wb?.planets?aspects(wa.planets,wb.planets):[];
  const smooth=cross.filter(x=>['六合','拱相'].includes(x.name)).length, tense=cross.filter(x=>['刑相','冲相'].includes(x.name)).length;
  return {...entity(),profile_ids:[a.id,b.id],profile_revisions:[a.revision,b.revision],chart_ids:charts.map(x=>x.id),type:'combined',rule_version:'experimental-0.1',disclaimer:DISCLAIMER+'评分为人为定义的娱乐指标，未经过效度验证，不提供综合匹配率。',dimensions:[
    {key:'elements',label:'五行分布差异',score:distance===null?null:Math.round(distance*100),max:100,explanation:'Σ|甲方数量−乙方数量| ÷ 16 × 100。数值高只表示分布差异大，不代表互补更好。',evidence:ba&&bb?[JSON.stringify(ba.elements),JSON.stringify(bb.elements)]:['缺少八字结果']},
    {key:'aspects',label:'柔和相位占比',score:smooth+tense?Math.round(smooth/(smooth+tense)*100):null,max:100,explanation:'六合与拱相数 ÷（六合、拱、刑、冲总数）×100；合相中性不计分，全部行星等权。没有纳入相位时不评分。',evidence:cross.map(x=>`${x.a}—${x.b} ${x.name}，偏差 ${x.orb}°`)},
    {key:'houses',label:'宫位互动',score:null,max:100,explanation:'宫位互动不设好坏分数；展示乙方太阳在甲方等宫中的位置。',evidence:wa?.ascendant!==undefined&&wb?.planets?[`乙方太阳落甲方第 ${Math.floor(norm(wb.planets[0].longitude-wa.ascendant)/30)+1} 宫`]:['缺少已验证的出生时间或宫位']},
    {key:'ziwei',label:'紫微结构对照',score:null,max:100,explanation:'尚未验证跨盘评分体系，仅提供独立命盘供查阅。',evidence:[]},
    {key:'xingsu',label:'星宿关系',score:null,max:100,explanation:'关系表来源待验证，不生成关系名称或分数。',evidence:[]}
  ]};
}
