import { calculate } from './engines';
self.onmessage = ({data}) => { try { self.postMessage({id:data.id,result:calculate(data.profile,data.type)}); } catch(error) { self.postMessage({id:data.id,error:error instanceof Error?error.message:String(error)}); } };
