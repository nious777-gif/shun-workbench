export interface Place {id:string;name:string;latitude:number;longitude:number;timezone:string}
export interface PlaceRegion {id:string;name:string;cities:Place[]}
export function placeFields(region:PlaceRegion,place:Place){
 if(!region.cities.some(p=>p.id===place.id))throw new Error('地点不属于所选地区');
 return {birthplace:region.name===place.name?region.name:`${region.name} / ${place.name}`,latitude:place.latitude,longitude:place.longitude,timezone:place.timezone};
}
