import type { ChartRecord } from './types';
export interface ReadingSection { rule_id:string; title:string; text:string; evidence:string[]; keyword:string }
interface TemplateRule { id:string; when:(c:ChartRecord)=>boolean; render:(c:ChartRecord)=>Omit<ReadingSection,'rule_id'>[] }
const stemElement:Record<string,string>={甲:'木',乙:'木',丙:'火',丁:'火',戊:'土',己:'土',庚:'金',辛:'金',壬:'水',癸:'水'};
const elementMeaning:Record<string,string>={木:'生发与伸展',火:'表达与温度',土:'承载与稳定',金:'秩序与收束',水:'流动与适应'};
const planetMeaning:Record<string,string>={太阳:'自我表达',月亮:'情绪体验',水星:'思考与沟通',金星:'审美与亲近方式',火星:'行动与动力',木星:'探索与扩展',土星:'边界与责任',天王星:'变化与突破',海王星:'想象与理想',冥王星:'深层变化'};
const houseTopics=['自我呈现','资源与价值','沟通与学习','居所与根基','创作与乐趣','日常与习惯','合作与关系','共享与边界','远行与观念','公共角色','群体与愿景','独处与内省'];
export const localRules:TemplateRule[]=[
  {id:'bazi.day-master.v2',when:c=>!!c.result.day_master,render:c=>{const stem=c.result.day_master!,element=stemElement[stem];return [{title:'日主：阅读四柱的参照点',text:`日主为${stem}${element||''}。传统五行意象常以“${elementMeaning[element]||'体系内分类'}”帮助记忆，但日主不能单独决定性格或喜用神。建议先辨认其他三柱相对日主的关系，再查阅十神。`,evidence:[`日柱 ${c.result.pillars?.[2]?.ganzhi||'未提供'}`],keyword:'日主'}];}},
  {id:'bazi.deities.v2',when:c=>!!c.result.pillars,render:c=>{const entries=c.result.pillars!.filter(p=>p.label!=='日');return [{title:'十神与藏干：先看对应关系',text:`天干十神为${entries.map(p=>`${p.label}柱${p.deity}`).join('、')}。这里只呈现相对日主的分类；同一种十神出现多次，也不等于相应现实事件必然发生。藏干列表不参与本页表层五行计数。`,evidence:c.result.pillars!.map(p=>`${p.label}柱 ${p.ganzhi}；藏干 ${p.hidden.join('、')}`),keyword:'十神'}];}},
  {id:'elements.distribution.v2',when:c=>!!c.result.elements,render:c=>{const items=Object.entries(c.result.elements!),max=Math.max(...items.map(([,n])=>n)),leaders=items.filter(([,n])=>n===max).map(([k])=>k);return [{title:'元素分布：描述数量，不判断强弱',text:`当前统计中，${leaders.join('、')}的数量最多（各 ${max}）。${c.type==='bazi'?'统计没有考虑月令、通根或合化，不能据此判断身强身弱，也不能把缺少的元素直接当成喜用神。':'每颗行星等权计数；太阳、月亮与外行星在解释中的权重并不因此相同。'}`,evidence:items.map(([k,n])=>`${k}：${n}`),keyword:c.type==='bazi'?'旺衰':'元素'}];}},
  {id:'bazi.luck.v2',when:c=>!!c.result.luck?.length,render:c=>[{title:'大运：周期索引',text:'大运表用于定位传统周期，可与原局并列查阅。年份区间是概览，交运瞬间需另外核对；本地模板不把某个周期写成发财、疾病或分离的预言。',evidence:c.result.luck!.slice(0,3).map(x=>`${x.ganzhi}：${x.start}–${x.end}`),keyword:'大运'}]},
  {id:'western.placements.v2',when:c=>!!c.result.planets,render:c=>c.result.planets!.map(p=>({title:`${p.name} · ${p.sign}${p.house?` · 第 ${p.house} 宫`:''}`,text:`传统占星常用${p.name}讨论“${planetMeaning[p.name]||'象征主题'}”。${p.house?`等宫制下落入第 ${p.house} 宫，可从“${houseTopics[p.house-1]}”这一主题展开自我观察。`:'当前未提供宫位，不补写宫位含义。'}落座与落宫是计算结果，象征含义不是对你的事实判断。`,evidence:[`黄经 ${p.longitude.toFixed(4)}°`,`星座内 ${(p.longitude%30).toFixed(2)}°`,p.house?'宫制：等宫':'宫位：未输出'],keyword:p.house?'宫位':p.name}))},
  {id:'western.aspects.v2',when:c=>!!c.result.aspects,render:c=>[{title:'相位：几何关系与解释分开看',text:c.result.aspects!.length?`当前容许度内找到 ${c.result.aspects!.length} 组相位。拱相与六合通常被传统解释为较易协调的联系，刑相与冲相常被用来讨论张力；两者都不等于现实中的好坏结局。下列先列出偏差最小的五组。`:'当前容许度内没有匹配相位。这仅意味着筛选条件下没有命中，不代表盘面“没有联系”。',evidence:[...c.result.aspects!].sort((a,b)=>a.orb-b.orb).slice(0,5).map(a=>`${a.a}—${a.b}：${a.name}，目标 ${a.angle}°，偏差 ${a.orb}°`),keyword:'相位'}]},
  {id:'ziwei.palaces.v2',when:c=>!!c.result.palaces,render:c=>c.result.palaces!.filter(p=>p.name==='命宫'||p.body).map(p=>({title:`${p.name}${p.body?' · 身宫所在':''}`,text:`此宫主星为${p.stars.join('、')||'无主星'}。${p.stars.length?'阅读时可先认识主星，再结合辅星、四化与三方四正。':'“无主星”是结构描述，不等于缺陷；借星等进一步规则尚未在本版自动解释。'}四化标签属于传统分类，尤其“化忌”不等于灾祸。`,evidence:[`${p.branch}宫`,...p.stars,...p.minor,`大限：${p.decade.join('–')} 岁`],keyword:'四化'}))},
  {id:'xingsu.scope.v2',when:c=>!!c.result.mansion,render:c=>[{title:'星宿：确认计算体系',text:'当前值来自历法二十八宿表，不是月球的实际天文位置，也不是宿曜二十七宿本命宿。本版不会直接将这个结果代入二十七宿关系表。',evidence:[c.result.mansion!,c.engine],keyword:'星宿'}]}
];
export function explainLocally(chart:ChartRecord):ReadingSection[] {
  return localRules.filter(rule=>rule.when(chart)).flatMap(rule=>rule.render(chart).map(section=>({...section,rule_id:rule.id})));
}
