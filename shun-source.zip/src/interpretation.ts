import { DISCLAIMER, type ChartRecord } from './types';
import { explainLocally, type ReadingSection } from './local-rules';
export interface Interpretation { provider:'local'|'ai'; text:string; disclaimer:string; rules:string[]; sections?:ReadingSection[] }
export interface InterpretationProvider { interpret(chart:ChartRecord,signal?:AbortSignal):Promise<Interpretation> }
export class LocalTemplateProvider implements InterpretationProvider {
  async interpret(c:ChartRecord):Promise<Interpretation> {
    const sections=explainLocally(c);
    return {provider:'local',sections,text:[c.result.summary,...sections.map(s=>`${s.title}\n${s.text}\n依据：${s.evidence.join('；')}`)].join('\n\n'),rules:[...new Set(sections.map(s=>s.rule_id))],disclaimer:DISCLAIMER};
  }
}
// A proxy must enforce its own quota and secrets. There is deliberately no key field in the browser.
export class AiProvider implements InterpretationProvider {
  constructor(private endpoint:string) {}
  async interpret(c:ChartRecord,signal?:AbortSignal):Promise<Interpretation> {
    const url=new URL(this.endpoint,location.origin);
    if(url.origin!==location.origin || !url.pathname.startsWith('/api/')) throw new Error('AI 代理必须为同源 /api/ 路径，API Key 只能放在服务端');
    const draft=await new LocalTemplateProvider().interpret(c);
    const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'omit',signal,body:JSON.stringify({task:'rewrite_only',chart:{type:c.type,result:c.result,rules:c.rules},draft:draft.text,instructions:'仅润色现有解释，不生成或修改排盘数据，不做确定性预测。'})});
    if(!response.ok) throw new Error(`AI 代理返回 ${response.status}；本地解读仍可使用`);
    const value:unknown=await response.json();
    if(!value||typeof value!=='object'||!('text' in value)||typeof value.text!=='string'||value.text.length>12000) throw new Error('代理返回格式无效，预期 {text:string}');
    return {provider:'ai',text:value.text,disclaimer:DISCLAIMER+' AI 润色可能有误，请与原始排盘核对。',rules:draft.rules};
  }
}
