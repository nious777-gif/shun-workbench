import Dexie, { type Table } from 'dexie';
import {IDBFactory,IDBKeyRange} from 'fake-indexeddb';
import { entity, now, type BirthProfile, type ChartRecord, type SynastryRecord, type KnowledgeArticle, type Favorite, type AppSettings, type ExportBundle } from './types';
import { validateProfile, resolveTime } from './time';
import { articles } from './knowledge';
import { parseBackup } from './backup';
export class ShunDB extends Dexie {
  profiles!:Table<BirthProfile>; charts!:Table<ChartRecord>; synastries!:Table<SynastryRecord>;
  articles!:Table<KnowledgeArticle>; favorites!:Table<Favorite>; settings!:Table<AppSettings>;
  constructor(name='shun-personal-v1',memory=false) { super(name,memory?{indexedDB:new IDBFactory(),IDBKeyRange}:undefined); this.version(1).stores({profiles:'id,nickname,updated_at',charts:'id,profile_id,type,created_at,[profile_id+type]',synastries:'id,*profile_ids,created_at',articles:'id,category,*tags',favorites:'id,&[target_type+target_id]',settings:'id'}); }
}
// Working records exist only in memory. vault.ts is the only persistent private-data writer.
export const db=new ShunDB('shun-memory',true);
export const defaultSettings=():AppSettings=>({...entity(),id:'singleton',theme:'system',default_timezone:'Asia/Shanghai',true_solar_default:false,zi_hour_rule:'00',ai_enabled:false,ai_proxy:''});
export async function initialize() { await db.open(); await db.articles.bulkPut(articles); if(!await db.settings.get('singleton')) await db.settings.put(defaultSettings()); }
export async function saveProfile(p:BirthProfile) {
  p={...p,nickname:p.nickname.trim(),birthplace:p.birthplace.trim(),timezone:p.timezone.trim(),is_leap_month:p.calendar==='lunar'&&p.is_leap_month};
  validateProfile(p); if(p.birth_time) resolveTime(p);
  const old=await db.profiles.get(p.id);
  const next={...p,nickname:p.nickname.trim(),revision:(old?.revision||0)+1,created_at:old?.created_at||p.created_at,updated_at:now()};
  await db.profiles.put(next); return next;
}
export async function deleteProfile(id:string) {
  await db.transaction('rw',[db.profiles,db.charts,db.synastries,db.favorites],async()=>{
    const ids=await db.charts.where('profile_id').equals(id).primaryKeys();
    const all=await db.favorites.toArray(); await db.favorites.bulkDelete(all.filter(x=>x.target_type==='chart'&&ids.includes(x.target_id)).map(x=>x.id));
    await db.charts.bulkDelete(ids); await db.synastries.where('profile_ids').equals(id).delete(); await db.profiles.delete(id);
  });
}
export async function exportData():Promise<ExportBundle> {
  return db.transaction('r',[db.profiles,db.charts,db.synastries,db.favorites,db.settings],async()=>({format:'shun-personal',schema_version:1,exported_at:now(),profiles:await db.profiles.toArray(),charts:await db.charts.toArray(),synastries:await db.synastries.toArray(),favorites:await db.favorites.toArray(),settings:(await db.settings.toArray()).map(s=>({...s,ai_proxy:'',ai_enabled:false}))}));
}
export async function clearPrivateData() {
  await db.transaction('rw',[db.profiles,db.charts,db.synastries,db.favorites,db.settings],async()=>{ await db.profiles.clear();await db.charts.clear();await db.synastries.clear();await db.favorites.clear();await db.settings.clear();await db.settings.put(defaultSettings()); });
}

/** Restore as new local copies: existing records and preferences are never overwritten. */
export async function restoreBackup(text:string) {
  const data=parseBackup(text),at=now();
  const profileIds=new Map(data.profiles.map(p=>[p.id,crypto.randomUUID()]));
  const chartIds=new Map(data.charts.map(c=>[c.id,crypto.randomUUID()]));
  await db.transaction('rw',[db.profiles,db.charts,db.synastries,db.favorites],async()=>{
    await db.profiles.bulkAdd(data.profiles.map(p=>({...p,id:profileIds.get(p.id)!,updated_at:at})));
    await db.charts.bulkAdd(data.charts.map(c=>({...c,id:chartIds.get(c.id)!,profile_id:profileIds.get(c.profile_id)!,input:{...c.input,id:profileIds.get(c.profile_id)!},imported_at:at})));
    await db.synastries.bulkAdd(data.synastries.map(s=>({...s,id:crypto.randomUUID(),profile_ids:s.profile_ids.map(id=>profileIds.get(id)!) as [string,string],chart_ids:s.chart_ids.map(id=>chartIds.get(id)!),imported_at:at})));
    for(const f of data.favorites){
      const target=f.target_type==='chart'?chartIds.get(f.target_id)!:f.target_id;
      if(f.target_type==='article'&&!articles.some(a=>a.id===target))continue;
      if(!await db.favorites.where('[target_type+target_id]').equals([f.target_type,target]).first())await db.favorites.add({...f,id:crypto.randomUUID(),target_id:target});
    }
  });
  return {profiles:data.profiles.length,charts:data.charts.length,synastries:data.synastries.length};
}
