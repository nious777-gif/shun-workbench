import Dexie,{type Table} from 'dexie';
export const SEVEN_DAYS=7*24*60*60*1000;
interface DeviceUnlock{id:string;key:CryptoKey;salt:string;createdAt:number;expiresAt:number}
class DeviceDB extends Dexie{sessions!:Table<DeviceUnlock>;constructor(){super('shun-device-unlock-v1');this.version(1).stores({sessions:'id'});}}
const device=new DeviceDB();
export async function forgetDevice(){await device.sessions.delete('main');}
export async function rememberDeviceKey(key:CryptoKey,salt:string){
 if(key.extractable||key.algorithm.name!=='AES-GCM')throw new Error('不能保存此解锁密钥');
 const createdAt=Date.now(),expiresAt=createdAt+SEVEN_DAYS;
 try{await device.sessions.put({id:'main',key,salt,createdAt,expiresAt});const saved=await device.sessions.get('main');if(!saved?.key||saved.key.extractable)throw new Error('密钥存储失败');return expiresAt;}
 catch{await forgetDevice();throw new Error('此浏览器无法记住解锁状态，请继续使用密码解锁');}
}
export async function readDeviceKey(salt:string){
 const row=await device.sessions.get('main');if(!row)return null;
 const now=Date.now();if(!Number.isFinite(row.createdAt)||!Number.isFinite(row.expiresAt)||row.expiresAt-row.createdAt!==SEVEN_DAYS||now<row.createdAt||now>=row.expiresAt||row.salt!==salt||!row.key||row.key.extractable){await forgetDevice();return null;}
 return row;
}
