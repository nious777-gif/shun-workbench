import Dexie,{type Table} from 'dexie';
import {db,initialize,exportData,defaultSettings,ShunDB,restoreBackup} from './db';
import {parseBackup} from './backup';
import {deriveKey,encryptText,decryptEnvelope,type CipherEnvelope} from './crypto';
interface VaultRow{id:string;revision:number;data:CipherEnvelope}
class VaultDB extends Dexie{vault!:Table<VaultRow>;constructor(){super('shun-encrypted-v1');this.version(1).stores({vault:'id'});}}
const disk=new VaultDB();
let key:CryptoKey|null=null,salt:Uint8Array|null=null,revision=0;
let queue:Promise<void>=Promise.resolve();
export async function vaultExists(){return !!await disk.vault.get('main');}
export async function legacyExists(){return Dexie.exists('shun-personal-v1');}
export async function unlockVault(password:string,create:boolean){
 const row=await disk.vault.get('main');
 if(create&&row)throw new Error('加密库已存在，请刷新并解锁');
 if(!create&&!row)throw new Error('未找到加密库');
 if(row){const unlocked=await decryptEnvelope(row.data,password);const bundle=parseBackup(unlocked.text);key=unlocked.key;salt=unlocked.salt;revision=row.revision;
 await initialize();await db.transaction('rw',db.tables,async()=>{for(const t of db.tables)if(t.name!=='articles')await t.clear();await db.profiles.bulkPut(bundle.profiles);await db.charts.bulkPut(bundle.charts);await db.synastries.bulkPut(bundle.synastries);await db.favorites.bulkPut(bundle.favorites);await db.settings.put({...bundle.settings[0]||defaultSettings(),ai_enabled:false,ai_proxy:''});});
 }else{if(password.length<12||password.length>128)throw new Error('请使用 12–128 位解锁密码，建议多个随机词组合');salt=crypto.getRandomValues(new Uint8Array(16));key=await deriveKey(password,salt);revision=0;await initialize();await persistVault();}
}
export function persistVault(){
 const operation=queue.then(async()=>{
 if(!key||!salt)throw new Error('请先解锁本地加密库');
 const text=JSON.stringify(await exportData());parseBackup(text);const data=await encryptText(text,key,salt);
 await disk.transaction('rw',disk.vault,async()=>{const current=await disk.vault.get('main');if((current?.revision||0)!==revision)throw new Error('另一页面已更新数据，请刷新后重试；本页未覆盖磁盘数据');await disk.vault.put({id:'main',revision:revision+1,data});revision++;});
 });queue=operation.catch(()=>{});return operation;
}
export async function encryptedBackup(){await persistVault();return (await disk.vault.get('main'))!.data;}
export async function readEncryptedBackup(text:string,password:string){return (await decryptEnvelope(JSON.parse(text),password)).text;}
export async function migrateLegacy(){
 if(!await legacyExists())return;
 const legacy=new ShunDB('shun-personal-v1');await legacy.open();
 try{const bundle={format:'shun-personal',schema_version:1,exported_at:new Date().toISOString(),profiles:await legacy.profiles.toArray(),charts:await legacy.charts.toArray(),synastries:await legacy.synastries.toArray(),favorites:await legacy.favorites.toArray(),settings:await legacy.settings.toArray()};
 await restoreBackup(JSON.stringify(bundle));await persistVault();
 }finally{legacy.close();}
 // User explicitly confirms this migration in the UI; encrypted copies have committed first.
 await Dexie.delete('shun-personal-v1');
}
