export type ChartType = 'bazi' | 'western' | 'ziwei' | 'xingsu';
export interface Entity { id: string; created_at: string; updated_at: string }
export interface BirthProfile extends Entity {
  nickname: string; gender: 'male' | 'female' | 'unspecified'; calendar: 'solar' | 'lunar';
  birth_date: string; birth_time: string | null; is_leap_month: boolean;
  birthplace: string; latitude: number; longitude: number; timezone: string;
  true_solar_time: boolean; zi_hour_rule: '23' | '00'; revision: number;
}
export interface Pillar { label: string; ganzhi: string; hidden: string[]; deity: string; elements: string }
export interface Planet { name: string; longitude: number; sign: string; house: number | null }
export interface Aspect { a: string; b: string; name: string; angle: number; orb: number }
export interface Palace { name: string; branch: string; stars: string[]; minor: string[]; decade: number[]; body: boolean }
export interface ChartData {
  summary: string; pillars?: Pillar[]; elements?: Record<string, number>; day_master?: string;
  luck?: { ganzhi: string; start: number; end: number }[];
  planets?: Planet[]; ascendant?: number; houses?: number[]; aspects?: Aspect[];
  palaces?: Palace[]; mansion?: string; relation_status?: string;
}
export interface ChartRecord extends Entity {
  imported_at?: string;
  profile_id: string; profile_revision: number; type: ChartType;
  input: Omit<BirthProfile, 'nickname'>; utc: string | null; calculation_time: string;
  engine: string; rules: string[]; warnings: string[];
  verification: 'needs_manual_review'; result: ChartData;
}
export interface ScoreDimension { key: string; label: string; score: number | null; max: 100; explanation: string; evidence: string[] }
export interface SynastryRecord extends Entity {
  imported_at?: string;
  profile_ids: [string,string]; profile_revisions: [number,number]; chart_ids: string[];
  type: 'combined'; rule_version: string; dimensions: ScoreDimension[]; disclaimer: string;
}
export interface KnowledgeArticle extends Entity { title: string; category: string; tags: string[]; body: string; source: string; search_text: string }
export interface Favorite extends Entity { target_type: 'article' | 'chart'; target_id: string }
export interface AppSettings extends Entity {
  id: 'singleton'; theme: 'system' | 'light' | 'dark'; default_timezone: string;
  true_solar_default: boolean; zi_hour_rule: '23' | '00'; ai_enabled: boolean; ai_proxy: string;
}
export interface ExportBundle { format: 'shun-personal'; schema_version: 1; exported_at: string; profiles: BirthProfile[]; charts: ChartRecord[]; synastries: SynastryRecord[]; favorites: Favorite[]; settings: AppSettings[] }
export const DISCLAIMER = '传统文化 / 娱乐参考。不是医疗、投资或关系决策建议。';
export const now = () => new Date().toISOString();
export const entity = (): Entity => { const at = now(); return { id: crypto.randomUUID(), created_at: at, updated_at: at }; };
