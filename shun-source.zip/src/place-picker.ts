import {defineComponent,ref,computed,watch,onMounted,onUnmounted,nextTick} from 'vue';
import {placeRegions} from './places-data';
import {placeFields,type Place} from './places';
const sortedRegions=[...placeRegions].sort((a,b)=>a.name.localeCompare(b.name,'zh-CN'));
const Wheel=defineComponent({
 props:{options:{type:Array<{id:string;name:string}>,required:true},selected:{type:String,required:true},label:{type:String,required:true}},emits:['select','settling'],
 setup(props,{emit}){
  const list=ref<HTMLElement|null>(null);let timer:ReturnType<typeof setTimeout>|undefined,syncing=false,epoch=0;
  async function sync(){const n=++epoch;syncing=true;clearTimeout(timer);emit('settling',false);await nextTick();if(n!==epoch)return;if(list.value)list.value.scrollTop=Math.max(0,props.options.findIndex(x=>x.id===props.selected))*44;requestAnimationFrame(()=>requestAnimationFrame(()=>{if(n===epoch)syncing=false;}));}
  function scroll(){if(syncing)return;emit('settling',true);clearTimeout(timer);timer=setTimeout(()=>{emit('settling',false);const i=Math.max(0,Math.min(props.options.length-1,Math.round((list.value?.scrollTop||0)/44)));const p=props.options[i];if(p&&p.id!==props.selected)emit('select',p.id);},80);}
  function choose(id:string){clearTimeout(timer);emit('settling',false);emit('select',id);void nextTick(sync);}
  function key(e:KeyboardEvent){let i=props.options.findIndex(x=>x.id===props.selected);if(e.key==='ArrowDown')i++;else if(e.key==='ArrowUp')i--;else if(e.key==='Home')i=0;else if(e.key==='End')i=props.options.length-1;else return;e.preventDefault();const p=props.options[Math.max(0,Math.min(props.options.length-1,i))];if(p)choose(p.id);}
  watch(()=>[props.options,props.selected],sync);onMounted(sync);onUnmounted(()=>clearTimeout(timer));
  return{list,scroll,choose,key};
 },template:`<div class="place-wheel-wrap"><div class="place-wheel-label">{{label}}</div><div class="place-wheel-highlight" aria-hidden="true"></div><div ref="list" class="place-wheel" role="listbox" :aria-label="label" tabindex="0" @keydown="key" @scroll.passive="scroll"><div v-for="p in options" :key="p.id" class="place-wheel-option" :class="{chosen:p.id===selected}" role="option" :aria-selected="p.id===selected" @click="choose(p.id)">{{p.name}}</div><div v-if="!options.length" class="place-wheel-option">没有匹配地点</div></div></div>`
});
export const PlacePicker=defineComponent({
 props:{initial:{type:String,default:''}},emits:['confirm','cancel'],components:{PlaceWheel:Wheel},
 setup(props,{emit}){
  const match=sortedRegions.find(r=>props.initial===r.name||props.initial.startsWith(r.name+' / '));
  const regionMoving=ref(false),cityMoving=ref(false);
  const regionId=ref(match?.id||'SH'),search=ref(''),cityId=ref('');
  const region=computed(()=>sortedRegions.find(r=>r.id===regionId.value)!);
  const cities=computed(()=>region.value.cities.filter(p=>p.name.toLowerCase().includes(search.value.trim().toLowerCase())).sort((a,b)=>a.name.localeCompare(b.name,'zh-CN')));
  cityId.value=region.value.cities.find(p=>props.initial===placeFields(region.value,p).birthplace)?.id||cities.value[0]?.id||'';
  const selected=computed(()=>cities.value.find(p=>p.id===cityId.value));
  function changeRegion(id:string){regionId.value=id;search.value='';cityId.value=cities.value[0]?.id||'';}
  watch(cities,rows=>{if(!rows.some(p=>p.id===cityId.value))cityId.value=rows[0]?.id||'';});
  function confirm(){if(selected.value)emit('confirm',placeFields(region.value,selected.value as Place));}
  const panel=ref<HTMLElement|null>(null);let previous:HTMLElement|null=null;let previousOverflow="";
  onMounted(()=>{previousOverflow=document.body.style.overflow;document.body.style.overflow="hidden";previous=document.activeElement as HTMLElement;panel.value?.focus();});onUnmounted(()=>{document.body.style.overflow=previousOverflow;previous?.focus();});
  function trap(e:KeyboardEvent){if(e.key!=='Tab')return;const focusables=panel.value?.querySelectorAll<HTMLElement>('button:not(:disabled),input,[tabindex="0"]');if(!focusables?.length)return;const first=focusables[0],last=focusables[focusables.length-1];if(e.shiftKey&&(document.activeElement===first||document.activeElement===panel.value)){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
  return{regionMoving,cityMoving,panel,trap,sortedRegions,regionId,region,search,cityId,cities,selected,changeRegion,confirm,emit};
 },template:`<div class="modal-backdrop" @click.self="emit('cancel')"><section ref="panel" tabindex="-1" class="card place-sheet" role="dialog" aria-modal="true" aria-labelledby="place-title" @keydown.esc="emit('cancel')" @keydown="trap"><div class="section-title"><button type="button" class="text-btn" @click="emit('cancel')">取消</button><h2 id="place-title">选择出生地</h2><button type="button" class="primary" :disabled="!selected||regionMoving||cityMoving" @click="confirm">确认地点</button></div><label class="place-search">查找当前地区的城市<input v-model="search" placeholder="输入城市名称，可选" autocomplete="off"></label><div class="place-wheels"><PlaceWheel :options="sortedRegions" :selected="regionId" label="省／地区" @select="changeRegion" @settling="regionMoving=$event"/><PlaceWheel :options="cities" :selected="cityId" label="城市／地点" @select="cityId=$event" @settling="cityMoving=$event"/></div><div class="place-preview" aria-live="polite"><template v-if="selected"><strong>{{region.name}} · {{selected.name}}</strong><span>纬度 {{selected.latitude.toFixed(4)}}° · 经度 {{selected.longitude.toFixed(4)}}°</span><span>{{selected.timezone}}</span></template><span v-else>没有匹配地点，可清空搜索或取消后手动填写。</span></div><p class="hint">上下滑动滚轮，或点选名称。地点库是城市／行政区参考坐标，并非医院定位；确认后可手动校正。大陆默认按北京时间，历史夏令时由 IANA 时区规则处理；如出生记录采用其他地方时间，请校正时区。</p><details class="hint"><summary>地点数据来源与范围</summary><p>CSC 开源地理数据库（ODbL 1.0），本地收录大陆 31 个省级地区及港澳台的部分城市／行政区。并非完整区县名录，坐标需按实际出生点复核。选择过程不请求定位，不联网查询。</p><a href="https://github.com/dr5hn/countries-states-cities-database" target="_blank" rel="noopener noreferrer">查看数据来源</a></details></section></div>`
});
