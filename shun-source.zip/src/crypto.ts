const enc=new TextEncoder(),dec=new TextDecoder();
export const ITERATIONS=600000;
export interface CipherEnvelope {format:'shun-encrypted';version:1;kdf:'PBKDF2-SHA256';iterations:number;salt:string;iv:string;ciphertext:string}
const b64=(bytes:Uint8Array)=>{let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s);};
const bytes=(s:string)=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const aad=enc.encode('shun-encrypted:v1');
export async function deriveKey(password:string,salt:Uint8Array){
 const material=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveKey']);
 return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt,iterations:ITERATIONS},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
export async function encryptText(text:string,key:CryptoKey,salt:Uint8Array):Promise<CipherEnvelope>{
 const iv=crypto.getRandomValues(new Uint8Array(12));
 const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad},key,enc.encode(text));
 return {format:'shun-encrypted',version:1,kdf:'PBKDF2-SHA256',iterations:ITERATIONS,salt:b64(salt),iv:b64(iv),ciphertext:b64(new Uint8Array(ciphertext))};
}
export function validateEnvelope(input:unknown):CipherEnvelope{
 const x=input as CipherEnvelope;
 if(!x||x.format!=='shun-encrypted'||x.version!==1||x.kdf!=='PBKDF2-SHA256'||x.iterations!==ITERATIONS||typeof x.salt!=='string'||typeof x.iv!=='string'||typeof x.ciphertext!=='string'||x.ciphertext.length>20*1024*1024)throw new Error('不支持或损坏的加密备份');
 try{if(bytes(x.salt).length!==16||bytes(x.iv).length!==12||bytes(x.ciphertext).length<16)throw 0;}catch{throw new Error('加密备份结构无效');}return x;
}
export async function decryptEnvelope(input:unknown,password:string){
 const data=validateEnvelope(input),salt=bytes(data.salt),key=await deriveKey(password,salt);
 try{const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(data.iv),additionalData:aad},key,bytes(data.ciphertext));return {text:dec.decode(plain),key,salt};}
 catch{throw new Error('密码不正确或加密数据已损坏；未修改原数据');}
}
