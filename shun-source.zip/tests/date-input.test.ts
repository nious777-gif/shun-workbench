import {describe,it,expect} from 'vitest';
import {dateDigits,joinBirthDate} from '../src/birth-date-input';
import {validateProfile} from '../src/time';
import {entity,type BirthProfile} from '../src/types';
const p=(extra:Partial<BirthProfile>={}):BirthProfile=>({...entity(),nickname:'表单测试',gender:'unspecified',calendar:'solar',birth_date:'2000-02-29',birth_time:null,is_leap_month:false,birthplace:'测试',latitude:31,longitude:121,timezone:'Asia/Shanghai',true_solar_time:false,zi_hour_rule:'00',revision:0,...extra});
describe('mobile date entry',()=>{
 it('joins single digit months and days without keyboard separators',()=>expect(joinBirthDate(['1990','6','5'])).toBe('1990-06-05'));
 it('does not invent missing date components',()=>expect(joinBirthDate(['1990','','5'])).toBe(''));
 it('normalizes full-width digits and limits each field',()=>{expect(dateDigits('１９９０',4)).toBe('1990');expect(dateDigits('06x3',2)).toBe('06');});
 it('accepts leap day and rejects impossible dates with useful Chinese message',()=>{expect(()=>validateProfile(p())).not.toThrow();expect(()=>validateProfile(p({birth_date:'1900-02-29'}))).toThrow('1901');expect(()=>validateProfile(p({birth_date:'2001-02-29'}))).toThrow('公历日期不存在');});
 it('validates lunar leap month independently from Gregorian rules',()=>{expect(()=>validateProfile(p({calendar:'lunar',birth_date:'2023-02-01',is_leap_month:true}))).not.toThrow();expect(()=>validateProfile(p({calendar:'lunar',birth_date:'2024-02-01',is_leap_month:true}))).toThrow('农历日期不存在');});
 it('gives actionable timezone validation',()=>expect(()=>validateProfile(p({timezone:'bad-zone'}))).toThrow('时区无效'));
});
