import 'fake-indexeddb/auto';
import { describe,it,expect,beforeEach } from 'vitest';
import { Solar } from 'lunar-javascript';
import { calculate,compare,angularDistance,aspects,ascendant } from '../src/engines';
import { resolveTime,solarDate } from '../src/time';
import { entity,type BirthProfile } from '../src/types';
import { db,initialize,saveProfile,deleteProfile,exportData,clearPrivateData } from '../src/db';
import { LocalTemplateProvider } from '../src/interpretation';
const profile=(extra:Partial<BirthProfile>={}):BirthProfile=>({...entity(),nickname:'测试专用虚构档案',gender:'male',calendar:'solar',birth_date:'2000-01-07',birth_time:'12:00',is_leap_month:false,birthplace:'测试坐标',latitude:31.2304,longitude:121.4737,timezone:'Asia/Shanghai',true_solar_time:false,zi_hour_rule:'00',revision:1,...extra});
describe('历法与输入边界（不是独立精度认证）',()=>{
  it('2000 春节农历转换固定样例',()=>{expect(solarDate(profile({calendar:'lunar',birth_date:'2000-01-01'}))).toBe('2000-02-05');});
  it('2024 春节农历转换固定样例',()=>{expect(solarDate(profile({calendar:'lunar',birth_date:'2024-01-01'}))).toBe('2024-02-10');});
  it('2023 闰二月初一固定样例',()=>{expect(solarDate(profile({calendar:'lunar',birth_date:'2023-02-01',is_leap_month:true}))).toBe('2023-03-22');});
  it('拒绝不存在的闰月',()=>expect(()=>resolveTime(profile({calendar:'lunar',birth_date:'2024-02-01',is_leap_month:true}))).toThrow());
  it('拒绝无效日期和经纬度',()=>{expect(()=>resolveTime(profile({birth_date:'2024-02-30'}))).toThrow();expect(()=>resolveTime(profile({latitude:91}))).toThrow();});
  it('上海冬季时区转 UTC',()=>{expect(resolveTime(profile()).instant.toISOString()).toBe('2000-01-07T04:00:00.000Z');});
  it('美国夏令时跳时和回拨歧义均拒绝',()=>{for(const [date,time] of [['2024-03-10','02:30'],['2024-11-03','01:30']])expect(()=>resolveTime(profile({birth_date:date,birth_time:time,timezone:'America/New_York'}))).toThrow();});
  it('1990 上海夏令时偏移',()=>{expect(resolveTime(profile({birth_date:'1990-06-15'})).instant.toISOString()).toBe('1990-06-15T03:00:00.000Z');});
  it('真太阳时仅调整传统时钟，不修改出生瞬间',()=>{const a=resolveTime(profile()),b=resolveTime(profile({true_solar_time:true}));expect(a.instant.toISOString()).toBe(b.instant.toISOString());expect(a.calc.toString()).not.toBe(b.calc.toString());});
  it('子时两种规则在 23:30 分歧，在 00:30 一致',()=>{const c=(time:string,rule:'23'|'00')=>calculate(profile({birth_time:time,zi_hour_rule:rule}),'bazi').result.pillars![2].ganzhi;expect(c('23:30','23')).not.toBe(c('23:30','00'));expect(c('00:30','23')).toBe(c('00:30','00'));});
  it('2000-01-07 甲子日回归样例',()=>expect(calculate(profile(),'bazi').result.pillars![2].ganzhi).toBe('甲子'));
  it('库内部立春交界前后换年月柱',()=>{
    const term=Solar.fromYmd(2024,2,4).getLunar().getJieQiTable()['立春'];
    const date=new Date(term.toYmdHms().replace(' ','T')+'+08:00');
    const convert=(delta:number)=>{const d=new Date(date.getTime()+delta+8*3600000).toISOString();return calculate(profile({birth_date:d.slice(0,10),birth_time:d.slice(11,16)}),'bazi').result.pillars!;};
    expect(convert(-60000)[0].ganzhi).not.toBe(convert(60000)[0].ganzhi);expect(convert(-60000)[1].ganzhi).not.toBe(convert(60000)[1].ganzhi);
  });
});
describe('确定性计算与降级',()=>{
  it.each(['bazi','western','ziwei','xingsu'] as const)('%s 可序列化且重复输入结果一致',type=>{const p=profile();expect(calculate(p,type).result).toEqual(calculate(p,type).result);expect(()=>JSON.stringify(calculate(p,type))).not.toThrow();});
  it('五行计数总数为八，不自动判旺衰',()=>{const c=calculate(profile(),'bazi');expect(Object.values(c.result.elements!).reduce((a,b)=>a+b)).toBe(8);expect(c.result.luck).toHaveLength(8);});
  it('未知出生时间不伪造命盘',()=>{for(const type of ['bazi','western','ziwei'] as const)expect(()=>calculate(profile({birth_time:null}),type)).toThrow();expect(calculate(profile({birth_time:null}),'xingsu').utc).toBeNull();});
  it('星盘十颗行星、十二个等宫',()=>{const c=calculate(profile(),'western').result;expect(c.planets).toHaveLength(10);expect(c.houses).toHaveLength(12);c.planets!.forEach(p=>{expect(p.longitude).toBeGreaterThanOrEqual(0);expect(p.longitude).toBeLessThan(360);expect(p.house).toBeGreaterThanOrEqual(1);expect(p.house).toBeLessThanOrEqual(12);});});
  it('高纬度不生成未验收宫位',()=>{const c=calculate(profile({latitude:70}),'western').result;expect(c.ascendant).toBeUndefined();expect(c.planets!.every(p=>p.house===null)).toBe(true);});
  it('跨 0 度的相位距离与边界',()=>{expect(angularDistance(359,1)).toBe(2);const p=(name:string,longitude:number)=>({name,longitude,sign:'',house:null});expect(aspects([p('a',359),p('b',5)])[0].name).toBe('合相');expect(aspects([p('a',359),p('b',5.001)])).toHaveLength(0);});
  it('紫微有十二宫与十四主星',()=>{const c=calculate(profile(),'ziwei').result;expect(c.palaces).toHaveLength(12);expect(c.palaces!.reduce((n,p)=>n+p.stars.length,0)).toBe(14);});
  it('星宿关系不编造',()=>{expect(calculate(profile(),'xingsu').result.relation_status).toContain('待验证');});
  it('相同结构五行差异为零，未验证维度保持空分',()=>{const a=profile(),b=profile();const records=[calculate(a,'bazi'),calculate(b,'bazi'),calculate(a,'western'),calculate(b,'western')];const s=compare(a,b,records);expect(s.dimensions[0].score).toBe(0);expect(s.dimensions.find(x=>x.key==='xingsu')!.score).toBeNull();expect(s.disclaimer).toContain('娱乐');expect(()=>compare(a,a,records)).toThrow();});
  it('本地模板有规则与免责声明',async()=>{const r=await new LocalTemplateProvider().interpret(calculate(profile(),'bazi'));expect(r.provider).toBe('local');expect(r.rules.length).toBeGreaterThan(0);expect(r.disclaimer).toContain('娱乐参考');});
});
describe('本地持久化与删除一致性',()=>{
  beforeEach(async()=>{await initialize();await clearPrivateData();});
  it('保存、编辑修订号、快照保留',async()=>{const p=await saveProfile(profile());expect(p.revision).toBe(1);const c=calculate(p,'bazi');await db.charts.put(c);const edited=await saveProfile({...p,nickname:'修改后的测试档案'});expect(edited.revision).toBe(2);expect((await db.charts.get(c.id))!.profile_revision).toBe(1);});
  it('导出完整实体且关闭 AI，不导出代理地址',async()=>{await saveProfile(profile());const data=await exportData();expect(data.profiles).toHaveLength(1);expect(data.format).toBe('shun-personal');expect(data.settings[0].ai_enabled).toBe(false);expect(data.settings[0].ai_proxy).toBe('');});
  it('删除档案级联记录但保留其他档案与文章收藏',async()=>{const a=await saveProfile(profile()),b=await saveProfile(profile());const ca=calculate(a,'bazi'),cb=calculate(b,'bazi');await db.charts.bulkPut([ca,cb]);await db.favorites.bulkPut([{...entity(),target_type:'chart',target_id:ca.id},{...entity(),target_type:'chart',target_id:cb.id},{...entity(),target_type:'article',target_id:'article-1'}]);await db.synastries.put(compare(a,b,[ca,cb]));await deleteProfile(a.id);expect(await db.charts.count()).toBe(1);expect(await db.profiles.count()).toBe(1);expect(await db.synastries.count()).toBe(0);expect(await db.favorites.count()).toBe(2);});
  it('清空私有数据保留知识库，设置恢复默认',async()=>{await saveProfile(profile());await clearPrivateData();expect(await db.profiles.count()).toBe(0);expect(await db.charts.count()).toBe(0);expect(await db.articles.count()).toBeGreaterThan(0);expect((await db.settings.get('singleton'))!.ai_enabled).toBe(false);});
});
