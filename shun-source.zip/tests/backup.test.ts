import 'fake-indexeddb/auto';
import { beforeEach,describe,it,expect } from 'vitest';
import { parseBackup } from '../src/backup';
import { db,initialize,saveProfile,exportData,clearPrivateData,restoreBackup } from '../src/db';
import { calculate,compare } from '../src/engines';
import { entity,type BirthProfile } from '../src/types';
import { LocalTemplateProvider } from '../src/interpretation';
const profile=():BirthProfile=>({...entity(),nickname:'导入测试（虚构）',gender:'female',calendar:'solar',birth_date:'2000-01-07',birth_time:'12:00',is_leap_month:false,birthplace:'测试坐标',latitude:31.23,longitude:121.47,timezone:'Asia/Shanghai',true_solar_time:false,zi_hour_rule:'00',revision:1});
beforeEach(async()=>{await initialize();await clearPrivateData();});
async function fixture(){
  const a=await saveProfile(profile()),b=await saveProfile(profile());
  const records=[calculate(a,'bazi'),calculate(a,'western'),calculate(a,'ziwei'),calculate(a,'xingsu'),calculate(b,'bazi'),calculate(b,'western')];
  await db.charts.bulkPut(records);await db.synastries.put(compare(a,b,records));
  await db.favorites.bulkAdd([{...entity(),target_type:'chart',target_id:records[0].id},{...entity(),target_type:'article',target_id:'article-1'}]);
  return exportData();
}
describe('备份校验与原子恢复',()=>{
  it('旧版导出结构通过，未知字段不进入数据库',async()=>{const b=await fixture();const raw={...b,unexpected:'discard'};expect(parseBackup(JSON.stringify(raw))).not.toHaveProperty('unexpected');});
  it('损坏 JSON、错误格式及未来版本拒绝',async()=>{expect(()=>parseBackup('{')).toThrow();const b=await fixture();expect(()=>parseBackup(JSON.stringify({...b,schema_version:99}))).toThrow();expect(()=>parseBackup(JSON.stringify({...b,format:'other'}))).toThrow();});
  it('拒绝原型污染字段',()=>expect(()=>parseBackup('{"__proto__":{"polluted":true}}')).toThrow());
  it('拒绝超大输入',()=>expect(()=>parseBackup(' '.repeat(10*1024*1024+1))).toThrow('10 MB'));
  it('重复 ID、悬空引用拒绝',async()=>{const b=await fixture();expect(()=>parseBackup(JSON.stringify({...b,profiles:[b.profiles[0],b.profiles[0]]}))).toThrow();expect(()=>parseBackup(JSON.stringify({...b,profiles:[]}))).toThrow();});
  it('无效坐标与未知时间格式拒绝',async()=>{const b=await fixture();b.profiles[0].latitude=95;expect(()=>parseBackup(JSON.stringify(b))).toThrow();b.profiles[0].latitude=0;b.profiles[0].birth_time='25:30';expect(()=>parseBackup(JSON.stringify(b))).toThrow();});
  it('相位引用不存在的行星拒绝',async()=>{const b=await fixture();b.charts.find(c=>c.type==='western')!.result.aspects![0].a='不存在的行星';expect(()=>parseBackup(JSON.stringify(b))).toThrow('行星');});
  it('空元素计数不能作为有效快照导入',async()=>{const b=await fixture();b.charts.find(c=>c.type==='bazi')!.result.elements={};expect(()=>parseBackup(JSON.stringify(b))).toThrow('元素');});
  it('非法分数拒绝且数据库没有半份导入',async()=>{const b=await fixture();b.synastries[0].dimensions[0].score=101;await expect(restoreBackup(JSON.stringify(b))).rejects.toThrow();expect(await db.profiles.count()).toBe(2);expect(await db.charts.count()).toBe(6);});
  it('恢复重映射所有引用，保留现有数据及设置',async()=>{
    const b=await fixture(),oldIds=new Set(b.profiles.map(p=>p.id));
    await db.settings.update('singleton',{theme:'dark'});
    const counts=await restoreBackup(JSON.stringify(b));expect(counts).toEqual({profiles:2,charts:6,synastries:1});
    expect(await db.profiles.count()).toBe(4);expect(await db.charts.count()).toBe(12);
    const restored=(await db.charts.toArray()).filter(c=>c.imported_at);expect(restored).toHaveLength(6);
    for(const c of restored){expect(oldIds.has(c.profile_id)).toBe(false);expect(c.input.id).toBe(c.profile_id);expect(await db.profiles.get(c.profile_id)).toBeDefined();}
    const syn=(await db.synastries.toArray()).find(s=>s.imported_at)!;for(const id of syn.chart_ids)expect(restored.some(c=>c.id===id)).toBe(true);
    expect(await db.favorites.count()).toBe(3);expect((await db.settings.get('singleton'))!.theme).toBe('dark');expect((await db.settings.get('singleton'))!.ai_enabled).toBe(false);
  });
  it('恢复后的备份可以再次校验导出',async()=>{const b=await fixture();await restoreBackup(JSON.stringify(b));expect(parseBackup(JSON.stringify(await exportData())).charts).toHaveLength(12);});
});
describe('规则模板可追溯且不修改原盘',()=>{
  it.each(['bazi','western','ziwei','xingsu'] as const)('%s 每节有规则 ID 和证据',async type=>{const c=calculate(profile(),type),before=JSON.stringify(c);const r=await new LocalTemplateProvider().interpret(c);expect(r.sections!.length).toBeGreaterThan(0);r.sections!.forEach(s=>{expect(s.rule_id).toBeTruthy();expect(s.evidence.length).toBeGreaterThan(0);});expect(JSON.stringify(c)).toBe(before);});
  it('星盘生成十颗行星各自的解释卡片',async()=>{const r=await new LocalTemplateProvider().interpret(calculate(profile(),'western'));expect(r.sections!.filter(s=>s.rule_id==='western.placements.v2')).toHaveLength(10);});
  it('高纬度不补写不存在的宫位',async()=>{const r=await new LocalTemplateProvider().interpret(calculate({...profile(),latitude:70},'western'));expect(r.text).toContain('当前未提供宫位');expect(r.text).not.toContain('undefined');});
});
