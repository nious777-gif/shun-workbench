import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import {describe,it,expect,vi} from 'vitest';
import {deriveKey,encryptText,decryptWithKey} from '../src/crypto';
import {rememberDeviceKey,readDeviceKey,forgetDevice,SEVEN_DAYS} from '../src/device-unlock';
import {unlockVault,rememberUnlockedDevice,autoUnlockVault,encryptedBackup} from '../src/vault';
describe('seven day device unlock',()=>{
 it('stores a non-exportable key, expires without sliding renewal and revokes',async()=>{
  const key=await deriveKey('test-password-only-2026',new Uint8Array(16));const start=Date.now();vi.spyOn(Date,'now').mockReturnValue(start);
  try{expect(await rememberDeviceKey(key,'salt')).toBe(start+SEVEN_DAYS);const r=await readDeviceKey('salt');expect(r?.key.extractable).toBe(false);const encrypted=await encryptText('test-only',key,new Uint8Array(16));expect((await decryptWithKey(encrypted,r!.key)).text).toBe('test-only');
  vi.mocked(Date.now).mockReturnValue(start+SEVEN_DAYS-1);expect(await readDeviceKey('salt')).not.toBeNull();vi.mocked(Date.now).mockReturnValue(start+SEVEN_DAYS);expect(await readDeviceKey('salt')).toBeNull();
  vi.mocked(Date.now).mockReturnValue(start);await rememberDeviceKey(key,'salt');expect(await readDeviceKey('other-vault')).toBeNull();await rememberDeviceKey(key,'salt');await forgetDevice();expect(await readDeviceKey('salt')).toBeNull();
  }finally{vi.restoreAllMocks();await forgetDevice();}
 });
 it('restores encrypted vault through remembered key and never exports session material',async()=>{
  await unlockVault('test-password-only-2026',true);const until=await rememberUnlockedDevice();expect(await autoUnlockVault()).toBe(until);const backup=await encryptedBackup();expect(Object.keys(backup)).not.toContain('key');expect(JSON.stringify(backup)).not.toContain('expiresAt');await forgetDevice();expect(await autoUnlockVault()).toBe(0);
  const disk=new Dexie('shun-device-unlock-v1');disk.version(1).stores({sessions:'id'});expect(await disk.table('sessions').count()).toBe(0);disk.close();
 });
});
