import {describe,it,expect} from 'vitest';
import {placeRegions} from '../src/places-data';
import {placeFields} from '../src/places';
describe('offline birthplace data',()=>{
 it('covers 34 regions with valid unique places and IANA zones',()=>{
  expect(placeRegions).toHaveLength(34);expect(new Set(placeRegions.map(r=>r.id)).size).toBe(34);
  for(const r of placeRegions){expect(r.cities.length).toBeGreaterThan(0);expect(new Set(r.cities.map(p=>p.id)).size).toBe(r.cities.length);for(const p of r.cities){expect(Number.isFinite(p.latitude)&&Math.abs(p.latitude)<=90).toBe(true);expect(Number.isFinite(p.longitude)&&Math.abs(p.longitude)<=180).toBe(true);expect(()=>new Intl.DateTimeFormat('zh-CN',{timeZone:p.timezone})).not.toThrow();}}
 });
 it('fills all location fields together without mutating the dataset',()=>{
  const r=placeRegions.find(r=>r.id==='SH')!;const p=r.cities[0];const original=JSON.stringify(r);expect(placeFields(r,p)).toEqual({birthplace:r.name===p.name?r.name:`${r.name} / ${p.name}`,latitude:p.latitude,longitude:p.longitude,timezone:'Asia/Shanghai'});expect(JSON.stringify(r)).toBe(original);
 });
 it('contains distinct HK Macau and Taiwan IANA zones',()=>{for(const zone of ['Asia/Hong_Kong','Asia/Macau','Asia/Taipei'])expect(placeRegions.some(r=>r.cities.some(p=>p.timezone===zone))).toBe(true);});
 it('rejects a city from another region',()=>{expect(()=>placeFields(placeRegions[0],placeRegions[1].cities[0])).toThrow();});
});
