import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import {describe,it,expect} from 'vitest';
import {deriveKey,encryptText,decryptEnvelope,validateEnvelope} from '../src/crypto';
import {unlockVault,persistVault,encryptedBackup} from '../src/vault';
import {db,saveProfile} from '../src/db';
import {entity,type BirthProfile} from '../src/types';
const password='fictitious-test-password-2026';
describe('本地隐私加密',()=>{
 it('随机盐和 IV；正确密码还原，错误密码和篡改拒绝',async()=>{
 const salt=crypto.getRandomValues(new Uint8Array(16)),key=await deriveKey(password,salt);
 expect(key.extractable).toBe(false);
 const a=await encryptText('私人出生信息',key,salt),b=await encryptText('私人出生信息',key,salt);
 expect(a.iv).not.toBe(b.iv);expect(a.ciphertext).not.toBe(b.ciphertext);
 expect((await decryptEnvelope(a,password)).text).toBe('私人出生信息');
 await expect(decryptEnvelope(a,'wrong')).rejects.toThrow('密码');
 await expect(decryptEnvelope({...a,ciphertext:(a.ciphertext[0]==='A'?'B':'A')+a.ciphertext.slice(1)},password)).rejects.toThrow();
 expect(()=>validateEnvelope({...a,iterations:1})).toThrow();
 },15000);
 it('磁盘只含密文，解锁恢复；冲突不覆盖',async()=>{
 await unlockVault(password,true);
 const p:BirthProfile={...entity(),nickname:'不可明文持久化',gender:'female',calendar:'solar',birth_date:'2000-01-07',birth_time:'12:00',is_leap_month:false,birthplace:'虚构',latitude:31,longitude:121,timezone:'Asia/Shanghai',true_solar_time:false,zi_hour_rule:'00',revision:0};
 await saveProfile(p);await persistVault();
 const backup=await encryptedBackup();expect(JSON.stringify(backup)).not.toContain(p.nickname);
 const native=new Dexie('shun-encrypted-v1');native.version(1).stores({vault:'id'});
 const row=await native.table('vault').get('main');expect(JSON.stringify(row)).not.toContain(p.birth_date);
 expect(await Dexie.exists('shun-memory')).toBe(false);
 await db.profiles.clear();await unlockVault(password,false);expect((await db.profiles.get(p.id))?.nickname).toBe(p.nickname);
 await native.table('vault').put({...row,revision:999});await expect(persistVault()).rejects.toThrow('另一页面');native.close();
 },15000);
});
